// const { Sequelize } = require('sequelize');
import { Sequelize} from 'sequelize';

// Initialize Sequelize with database connection details
const sequelize = new Sequelize('thread_db', 'root', '', {
    host: 'localhost',
    dialect: 'mysql',
    port: 3306,  // Default MySQL port
});

module.exports = sequelize;
