// const express = require('express');
import express from 'express';
import cors from 'cors';
// const bodyParser = require('body-parser');
import bodyParser from 'body-parser';
// const sequelize = require('./config/database');
// const threadRoutes = require('./routes/threads.js');
import threadRoutes from './routes/threads.js';
// const commentRoutes = require('./routes/comments.js');
import commentRoutes from './routes/comments.js';
// const likeRoutes = require('./routes/likes.js');
import likeRoutes from './routes/likes.js';
// const shareRoutes = require('./routes/shares.js');
import shareRoutes from './routes/shares.js';

const app = express();
const port = process.env.PORT || 8080;

app.use(cors());

app.use(express.json());

app.use(bodyParser.json());

// Sync database
// sequelize.sync()
//     .then(() => console.log('Database connected and synced'))
//     .catch(err => console.log('Error syncing database:', err));

// Use routes
app.use('/v1', threadRoutes);
app.use('/v1', commentRoutes);
app.use('/v1', likeRoutes);
app.use('/v1', shareRoutes);

// Start server
app.listen(port, () => {
    console.log(`Server running on port  http://localhost:${port}`);
});
