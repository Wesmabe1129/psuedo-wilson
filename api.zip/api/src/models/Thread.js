// const { DataTypes } = require('sequelize');
import { DataTypes } from 'sequelize';
// const sequelize = require('../config/database');
import sequelize from '../config/database';

// Define the Thread model
const Thread = sequelize.define('Thread', {
    title: {
        type: DataTypes.STRING,
        allowNull: false
    },
    body: {
        type: DataTypes.TEXT,
        allowNull: true
    }
}, {
    timestamps: true,
    createdAt: 'created_at',
    updatedAt: false
});

module.exports = Thread;
